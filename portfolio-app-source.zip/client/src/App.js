import React from "react";
import Projects from "./components/Projects";
import "./App.css";

function App() {
  return (
    <div>
      <h1>Praneeth's Portfolio</h1>
      <Projects />
    </div>
  );
}

export default App;
