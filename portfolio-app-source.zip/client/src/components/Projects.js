import React, { useEffect, useState } from "react";
import axios from "axios";

function Projects() {
  const [projects, setProjects] = useState([]);

  useEffect(() => {
    axios.get("http://localhost:5000/api/projects")
      .then(res => setProjects(res.data))
      .catch(err => console.log(err));
  }, []);

  return (
    <div>
      <h2>Projects</h2>
      {projects.map(project => (
        <div key={project._id} className="card">
          <h3>{project.title}</h3>
          <p>{project.description}</p>
          <a href={project.github}>GitHub</a>
        </div>
      ))}
    </div>
  );
}

export default Projects;
